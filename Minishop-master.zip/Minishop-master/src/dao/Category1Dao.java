package dao;

public class Category1Dao {

}
