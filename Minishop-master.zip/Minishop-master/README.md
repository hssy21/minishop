# Minishop
A mini project using JAVA, JSP&Servlet and Oracle database.

## What is Minishop?
Minishop is a small shopping mall made of MVC structure. 
It is divided into a general user page and an administrator page. 
Administrators can manage goods and manage users, and users can view and buy registered products. 
It is also possible to communicate with the administrator and user through the Notice bulletin boards and Q&A bulletin boards.

## Project Member
* 최형우(Choe, Hyungwoo)
* 원웅재(Won, Woongjae)
* 홍성윤(Hong, Sungyoon)
